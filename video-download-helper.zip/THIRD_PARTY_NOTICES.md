## Third-party notices

### mux.js (TS → MP4 transmux)

- Project: `mux.js`
- Repository: `https://github.com/videojs/mux.js`
- Version: `6.3.0` (bundled file: `js/vendor/mux.min.js`)
- License: Apache License 2.0


